CREATE TABLE kanban_board ( --Таблица канбан-доски
    id_board SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    FIO_owner VARCHAR(255) NOT NULL,
    max_tracks_count INTEGER NOT NULL DEFAULT 10 CHECK (max_tracks_count > 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO kanban_board (name, FIO_owner) VALUES ('Проект 29103', 'Дягерев А.Ю.');

CREATE TABLE tracks_kanban_board ( --Таблица дорожек канбан-доски
    id_track SERIAL PRIMARY KEY,
    id_board INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    position_track INTEGER NOT NULL,
    max_card_count INTEGER NOT NULL DEFAULT 100 CHECK (max_card_count > 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_board FOREIGN KEY (id_board) REFERENCES kanban_board(id_board)
      ON DELETE CASCADE
);

INSERT INTO tracks_kanban_board (id_board, name, position_track)
VALUES (1, 'Создано', 1),
(1, 'Анализ', 2),
(1, 'Системный анализ', 3),
(1, 'Реализация серверной части', 4),
(1, 'Реализация клиентской части', 5),
(1, 'Тестирование', 6),
(1, 'Валидация', 7),
(1, 'Развертывание', 8),
(1, 'Дорожка 1', 9),
(1, 'Дорожка 2', 10);
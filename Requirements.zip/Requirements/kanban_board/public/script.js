// Конфигурация
const BOARD_ID = 1;

// Глобальные переменные
let tracksData = [];
let originalTracksData = [];
let availableCards = [];
let currentTrackForAdding = null;
let selectedCardIds = new Set(); // Храним ID карточек вместо DOM-элементов
let warningShownCards = new Set();
let mode = 'view';
let currentCardId = null;
let currentCardData = null;
let activeTraces = new Set();
let deletedTables = new Set();
let selectedImage = null;

// Вспомогательные функции

// Вычисляет количество дней до дедлайна
function getDaysUntilDeadline(deadlineStr) {
    if (!deadlineStr) return null;
    const deadline = new Date(deadlineStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    deadline.setHours(0, 0, 0, 0);
    const diffTime = deadline - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

// Показывает предупреждение о приближающемся дедлайне
function showDeadlineWarning(cardName, daysLeft) {
    const modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
    modal.style.zIndex = '3000';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    const content = document.createElement('div');
    content.style.backgroundColor = '#fff';
    content.style.padding = '20px';
    content.style.borderRadius = '12px';
    content.style.maxWidth = '400px';
    content.style.textAlign = 'center';
    content.style.boxShadow = '0 5px 20px rgba(0,0,0,0.3)';
    content.innerHTML = `
        <h2 style="color: #8B0000;">⚠️ Внимание!</h2>
        <p style="font-size: 16px; margin: 15px 0;">
            Карточка <strong>"${escapeHtml(cardName)}"</strong>
            закончится через <strong style="color: #8B0000;">${daysLeft} дня(ей)</strong>!
        </p>
        <button id="warningOkBtn" style="padding: 8px 20px; background: #8B0000; color: white; border: none; border-radius: 5px; cursor: pointer;">OK</button>
    `;
    modal.appendChild(content);
    document.body.appendChild(modal);
    document.getElementById('warningOkBtn').onclick = () => modal.remove();
    setTimeout(() => { if (modal.parentNode) modal.remove(); }, 5000);
}

// Определяет уровень приоритета
function detectPriority(priorityText) {
    if (!priorityText) return { level: 'Средний', hasPlus: false };
    const text = String(priorityText).toLowerCase().trim();
    const hasPlus = text.includes('+');
    const cleanText = text.replace('+', '').trim();
    if (cleanText.includes('критич') || cleanText.includes('максимальн')) {
        return { level: 'Критический', hasPlus: false };
    }
    if (cleanText.includes('очень высок') || cleanText.includes('высок')) {
        return { level: 'Высокий', hasPlus: hasPlus || cleanText.includes('очень') };
    }
    if (cleanText.includes('средн')) {
        return { level: 'Средний', hasPlus: hasPlus };
    }
    if (cleanText.includes('ниже средн')) {
        return { level: 'Низкий', hasPlus: true };
    }
    if (cleanText.includes('низк')) {
        return { level: 'Низкий', hasPlus: hasPlus };
    }
    return { level: 'Средний', hasPlus: false };
}

// Возвращает CSS-класс для приоритета
function getPriorityClass(priority) {
    const { level, hasPlus } = detectPriority(priority);
    if (level === 'Высокий') return hasPlus ? 'priority-high-plus' : 'priority-high';
    if (level === 'Средний') return hasPlus ? 'priority-medium-plus' : 'priority-medium';
    if (level === 'Низкий') return hasPlus ? 'priority-low-plus' : 'priority-low';
    if (level === 'Критический') return 'priority-critical';
    return 'priority-medium';
}

// Возвращает текст для отображения приоритета
function getPriorityDisplayText(priority) {
    const { level, hasPlus } = detectPriority(priority);
    return hasPlus ? level + '+': level;
}

// Возвращает числовое значение приоритета для сортировки
function getPriorityValue(priorityText) {
    const priorityOrder = {
        'Низкий': 1, 'Низкий+': 2, 'Ниже среднего': 3,
        'Средний': 4, 'Средний+': 5,
        'Высокий': 6, 'Высокий+': 7, 'Очень высокий': 8,
        'Критический': 9, 'Максимальный': 10
    };
    const displayText = getPriorityDisplayText(priorityText);
    return priorityOrder[displayText] || 5;
}

// Списки для генерации мок-карточек
const priorities = ["Низкий", "Низкая+", "Средний", "Средняя+", "Высокий", "Очень высокая", "Критическая", "Максимальная"];
const responsiblePersons = ["Иванов А.А.", "Петров Б.Б.", "Сидоров В.В.", "Кузнецова Д.Е.", "Михайлов С.С."];

// Генерирует мок-карточки
function generateMockCards(count = 100) {
    const cards = [];
    const today = new Date();
    for (let i = 1; i <= count; i++) {
        const deadlineOffset = Math.floor(Math.random() * 41) - 10;
        const deadlineDate = new Date(today);
        deadlineDate.setDate(today.getDate() + deadlineOffset);
        cards.push({
            fakeId: Date.now() + Math.random() + i,
            name: `Карточка ${i}`,
            importance_estimate: priorities[Math.floor(Math.random() * priorities.length)],
            owner: responsiblePersons[Math.floor(Math.random() * responsiblePersons.length)],
            deadline: deadlineDate.toISOString().split('T')[0],
            selected: false,
            isFake: true
        });
    }
    return cards;
}

// Форматирует дату в ДД.ММ.ГГГГ
function formatDate(dateStr) {
    if (!dateStr) return 'Не указан';
    const d = new Date(dateStr);
    return `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.${d.getFullYear()}`;
}

// Экранирует HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Показывает уведомление
function showToast(message, isError = false) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.style.backgroundColor = isError ? '#dc2626' : '#333';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2000);
}

// Фильтрация и сортировка
let currentSearchTerm = '';
let currentSortType = 'default';

function applyFiltersAndSort() {
    tracksData = JSON.parse(JSON.stringify(originalTracksData));

    if (currentSearchTerm.trim() !== '') {
        const term = currentSearchTerm.trim().toLowerCase();
        tracksData.forEach(track => {
            track.cards = track.cards.filter(card => {
                return (card.name && card.name.toLowerCase().includes(term)) ||
                       (card.owner && card.owner.toLowerCase().includes(term)) ||
                       (card.deadline && formatDate(card.deadline).toLowerCase().includes(term)) ||
                       (card.importance_estimate && card.importance_estimate.toLowerCase().includes(term));
            });
        });
    }

    if (currentSortType !== 'default') {
        tracksData.forEach(track => {
            track.cards.sort((a, b) => {
                switch (currentSortType) {
                    case 'nameAsc': return (a.name || '').localeCompare(b.name || '');
                    case 'nameDesc': return (b.name || '').localeCompare(a.name || '');
                    case 'ownerAsc': return (a.owner || '').localeCompare(b.owner || '');
                    case 'ownerDesc': return (b.owner || '').localeCompare(a.owner || '');
                    case 'deadlineAsc': return (a.deadline || '').localeCompare(b.deadline || '');
                    case 'deadlineDesc': return (b.deadline || '').localeCompare(a.deadline || '');
                    case 'priorityAsc': return getPriorityValue(a.importance_estimate) - getPriorityValue(b.importance_estimate);
                    case 'priorityDesc': return getPriorityValue(b.importance_estimate) - getPriorityValue(a.importance_estimate);
                    default: return 0;
                }
            });
        });
    }

    updateStats();
    renderBoard();
}

function updateStats() {
    let total = 0;
    let visible = 0;
    originalTracksData.forEach(t => total += t.cards.length);
    tracksData.forEach(t => visible += t.cards.length);
    document.getElementById('totalCount').textContent = total;
    document.getElementById('visibleCount').textContent = visible;
}

function resetFilters() {
    currentSearchTerm = '';
    currentSortType = 'default';
    document.getElementById('searchInput').value = '';
    document.getElementById('searchInput').placeholder = 'Поиск по карточкам';
    document.getElementById('sortSelect').value = 'default';
    tracksData = JSON.parse(JSON.stringify(originalTracksData));
    selectedCardIds.clear(); // Очищаем выделения при сбросе фильтров
    updateStats();
    renderBoard();
    showToast('🔄 Фильтры сброшены');
}

// Инициализация фильтров
function initFilters() {
    const filterPanel = document.getElementById('filterPanel');
    const filterToggleBtn = document.getElementById('filterToggleBtn');
    const applyFilterBtn = document.getElementById('applyFilterBtn');
    const resetFilterBtn = document.getElementById('resetFilterBtn');
    const sortSelect = document.getElementById('sortSelect');
    const searchInput = document.getElementById('searchInput');

    filterToggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        filterPanel.classList.toggle('show');
    });

    document.addEventListener('click', (e) => {
        if (!filterPanel.contains(e.target) && e.target !== filterToggleBtn && !filterToggleBtn.contains(e.target)) {
            filterPanel.classList.remove('show');
        }
    });

    applyFilterBtn.addEventListener('click', () => {
        currentSortType = sortSelect.value;
        applyFiltersAndSort();
        filterPanel.classList.remove('show');
        showToast(`🔍 Применена сортировка: ${sortSelect.options[sortSelect.selectedIndex].text}`);
    });

    resetFilterBtn.addEventListener('click', () => {
        resetFilters();
        filterPanel.classList.remove('show');
    });

    searchInput.addEventListener('input', (e) => {
        currentSearchTerm = e.target.value;
        if (currentSearchTerm.trim() !== '') {
            searchInput.placeholder = currentSearchTerm;
        } else {
            searchInput.placeholder = 'Поиск по карточкам';
        }
        applyFiltersAndSort();
    });

    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && searchInput.value.trim() === '') {
            searchInput.placeholder = 'Поиск по карточкам';
        }
    });

    document.querySelector('h1').addEventListener('dblclick', () => {
        resetFilters();
    });
}

// Переключение выделения карточки
function toggleCardSelection(cardDiv, cardKey) {
    if (cardDiv.classList.contains('selected')) {
        cardDiv.classList.remove('selected');
        selectedCardIds.delete(cardKey);
        showToast(`✅ Выделение снято (${selectedCardIds.size})`);
    } else {
        cardDiv.classList.add('selected');
        selectedCardIds.add(cardKey);
        showToast(`✅ Выделена карточка (${selectedCardIds.size})`);
    }
}

// Снятие всех выделений
function clearAllSelections() {
    document.querySelectorAll('.card.selected').forEach(card => {
        card.classList.remove('selected');
    });
    selectedCardIds.clear();
}

// Удаление выделенных карточек
async function deleteSelectedCards() {
    if (selectedCardIds.size === 0) {
        showToast('⚠️ Нет выделенных карточек', true);
        return;
    }

    const cardsToDelete = [];
    for (let cardKey of selectedCardIds) {
        const [trackId, cardId, isFake] = cardKey.split('|');
        cardsToDelete.push({
            id: cardId,
            trackId: parseInt(trackId),
            isFake: isFake === 'true'
        });
    }

    let deletedCount = 0;
    for (const card of cardsToDelete) {
        const track = tracksData.find(t => t.id_track === card.trackId);
        if (track) {
            if (!card.isFake && card.id && !isNaN(parseInt(card.id))) {
                try {
                    const response = await fetch(`/api/cards/${parseInt(card.id)}`, { method: 'DELETE' });
                    if (response.ok) {
                        deletedCount++;
                        track.cards = track.cards.filter(c => c.id_card !== parseInt(card.id));
                    }
                } catch (err) {
                    console.error(err);
                }
            } else if (card.isFake) {
                const cardIndex = track.cards.findIndex(c => c.fakeId == card.id);
                if (cardIndex !== -1) {
                    track.cards.splice(cardIndex, 1);
                    deletedCount++;
                }
            }
        }
    }

    syncOriginalAfterDelete(cardsToDelete);
    selectedCardIds.clear(); // Очищаем Set с ID
    applyFiltersAndSort();
    showToast(`🗑️ Удалено ${deletedCount} карточек`);
}

function syncOriginalAfterDelete(deletedItems) {
    deletedItems.forEach(item => {
        const origTrack = originalTracksData.find(t => t.id_track === item.trackId);
        if (origTrack) {
            if (item.isFake) {
                origTrack.cards = origTrack.cards.filter(c => c.fakeId != item.id);
            } else {
                origTrack.cards = origTrack.cards.filter(c => c.id_card != item.id);
            }
        }
    });
}

// Переименование дорожки
async function editTrackName(trackId, currentName) {
    const newName = prompt('Введите новое название дорожки:', currentName);
    if (!newName || newName.trim() === '' || newName === currentName) return;
    try {
        const response = await fetch(`/api/tracks/${trackId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: newName.trim() })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'Ошибка обновления');
        if (data.success) {
            const track = tracksData.find(t => t.id_track === trackId);
            const origTrack = originalTracksData.find(t => t.id_track === trackId);
            if (track) track.name = newName.trim();
            if (origTrack) origTrack.name = newName.trim();
            renderBoard();
            showToast(`✏️ Дорожка переименована в "${newName.trim()}"`);
        }
    } catch (err) {
        showToast('❌ Ошибка при переименовании: ' + err.message, true);
    }
}

// Перемещение карточки между дорожками
async function moveCardToAnotherTrack(cardId, isFake, fromTrackId, toTrackId) {
    const fromTrackOrig = originalTracksData.find(t => t.id_track === fromTrackId);
    const toTrackOrig = originalTracksData.find(t => t.id_track === toTrackId);
    if (!fromTrackOrig || !toTrackOrig) return false;

    let movedCard = null;
    if (isFake) {
        const idx = fromTrackOrig.cards.findIndex(c => c.fakeId == cardId);
        if (idx !== -1) {
            movedCard = fromTrackOrig.cards.splice(idx, 1)[0];
            toTrackOrig.cards.push(movedCard);
        }
    } else {
        try {
            const response = await fetch(`/api/cards/${parseInt(cardId)}/move`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ targetTrackId: toTrackId })
            });
            const data = await response.json();
            if (response.ok && data.success) {
                const idx = fromTrackOrig.cards.findIndex(c => c.id_card == cardId);
                if (idx !== -1) {
                    movedCard = fromTrackOrig.cards.splice(idx, 1)[0];
                    movedCard.id_track = toTrackId;
                    toTrackOrig.cards.push(movedCard);
                }
            } else {
                showToast('❌ Ошибка перемещения', true);
                return false;
            }
        } catch (err) {
            showToast('❌ Ошибка сервера', true);
            return false;
        }
    }
    applyFiltersAndSort();
    showToast(`🔄 Карточка перемещена`);
    return true;
}

// Рендер доски
function renderBoard() {
    const boardContainer = document.getElementById('board');
    boardContainer.innerHTML = '';
    tracksData.forEach((track, idx) => {
        const trackDiv = document.createElement('div');
        trackDiv.className = `track track-${(idx % 5) + 1}`;
        trackDiv.dataset.trackId = track.id_track;

        trackDiv.addEventListener('dragover', (e) => {
            e.preventDefault();
            trackDiv.classList.add('drag-over-track');
        });
        trackDiv.addEventListener('dragleave', () => trackDiv.classList.remove('drag-over-track'));
        trackDiv.addEventListener('drop', async (e) => {
            e.preventDefault();
            trackDiv.classList.remove('drag-over-track');
            if (!draggedCard) return;
            if (draggedCard.sourceTrackId === track.id_track) return;
            await moveCardToAnotherTrack(draggedCard.cardId, draggedCard.isFake, draggedCard.sourceTrackId, track.id_track);
        });

        const headerDiv = document.createElement('div');
        headerDiv.className = 'track-header';
        const titleSpan = document.createElement('span');
        titleSpan.className = 'track-name';
        titleSpan.textContent = track.name;
        titleSpan.ondblclick = () => editTrackName(track.id_track, track.name);
        const countSpan = document.createElement('span');
        countSpan.className = 'track-count';
        countSpan.textContent = track.cards.length;
        headerDiv.appendChild(titleSpan);
        headerDiv.appendChild(countSpan);
        trackDiv.appendChild(headerDiv);

        const cardsContainer = document.createElement('div');
        cardsContainer.className = 'cards-container';
        track.cards.forEach((card, cardIndex) => {
            cardsContainer.appendChild(renderCard(card, track.id_track, cardIndex));
        });
        trackDiv.appendChild(cardsContainer);

        const addButton = document.createElement('button');
        addButton.textContent = '+ Добавить карточки';
        addButton.addEventListener('click', () => openModalForTrack(track));
        trackDiv.appendChild(addButton);

        boardContainer.appendChild(trackDiv);
    });
}

// Рендер одной карточки
function renderCard(card, trackId, cardIndex) {
    const cardDiv = document.createElement('div');
    const cardKey = `${trackId}|${card.id_card || card.fakeId}|${card.isFake || false}`;
    cardDiv.className = 'card';
    cardDiv.dataset.cardId = card.id_card || card.fakeId;
    cardDiv.dataset.isFake = card.isFake || false;
    cardDiv.dataset.trackId = trackId;
    cardDiv.dataset.cardKey = cardKey;

    // Проверяем выделение по ID
    if (selectedCardIds.has(cardKey)) {
        cardDiv.classList.add('selected');
    }

    const daysLeft = getDaysUntilDeadline(card.deadline);
    if (daysLeft !== null && daysLeft >= 0 && daysLeft <= 4) {
        cardDiv.classList.add('warning-deadline');
        const cardKeyWarning = card.id_card || card.fakeId;
        if (!warningShownCards.has(cardKeyWarning)) {
            warningShownCards.add(cardKeyWarning);
            showDeadlineWarning(card.name, daysLeft);
        }
    }

    const priorityText = getPriorityDisplayText(card.importance_estimate);
    const priorityClass = getPriorityClass(card.importance_estimate);

    cardDiv.innerHTML = `
        <h3>${escapeHtml(card.name) || 'Без названия'}</h3>
        <div class="card-title-bar"></div>
        <div class="info">
            <div class="priority-row">
                <span class="icon flag"></span>
                <span class="priority-wrapper ${priorityClass}">
                    <span class="priority-dot"></span>
                    <span class="priority-text">${priorityText}</span>
                </span>
            </div>
            <div><span class="icon person"></span> ${escapeHtml(card.owner) || 'Не указан'}</div>
            <div><span class="icon calendar"></span> ${formatDate(card.deadline)}</div>
        </div>
    `;

    setupDragAndDrop(cardDiv, trackId, cardIndex, card.id_card || card.fakeId, card.isFake || false);

    cardDiv.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        const isFake = cardDiv.dataset.isFake === 'true';
        if (!isFake) {
            openCardSidebar(cardDiv.dataset.cardId, card);
        }
    });

    // Обработка выделения карточки
    let pressTimer = null;
    let isLongPress = false;

    cardDiv.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        isLongPress = false;
        pressTimer = setTimeout(() => {
            isLongPress = true;
            toggleCardSelection(cardDiv, cardKey);
        }, 500);
    });

    cardDiv.addEventListener('mouseup', (e) => {
        clearTimeout(pressTimer);
        // Если это был клик (не долгое нажатие) и не было выделения через Ctrl/Cmd
        if (!isLongPress && !e.ctrlKey && !e.metaKey) {
            // Снимаем выделение со всех карточек, кроме текущей
            if (!cardDiv.classList.contains('selected')) {
                clearAllSelections();
                toggleCardSelection(cardDiv, cardKey);
            } else if (!e.ctrlKey && !e.metaKey) {
                // Если карточка уже выделена и нет Ctrl - снимаем все выделения
                clearAllSelections();
            }
        }
        isLongPress = false;
    });

    cardDiv.addEventListener('mouseleave', () => {
        clearTimeout(pressTimer);
        isLongPress = false;
    });

    // Поддержка Ctrl/Cmd для множественного выделения
    cardDiv.addEventListener('click', (e) => {
        if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            toggleCardSelection(cardDiv, cardKey);
        }
    });

    return cardDiv;
}

// Drag and Drop
let draggedCard = null;
function setupDragAndDrop(cardElement, trackId, cardIndex, cardId, isFake) {
    cardElement.setAttribute('draggable', 'true');
    cardElement.dataset.trackId = trackId;
    cardElement.dataset.cardIndex = cardIndex;
    cardElement.dataset.cardId = cardId;
    cardElement.dataset.isFake = isFake;

    cardElement.addEventListener('dragstart', (e) => {
        draggedCard = {
            element: cardElement,
            sourceTrackId: trackId,
            sourceIndex: cardIndex,
            cardId: cardId,
            isFake: isFake
        };
        cardElement.classList.add('dragging');
    });
    cardElement.addEventListener('dragend', () => {
        cardElement.classList.remove('dragging');
        document.querySelectorAll('.drag-over, .drag-over-track').forEach(el => el.classList.remove('drag-over', 'drag-over-track'));
        draggedCard = null;
    });
    cardElement.addEventListener('dragover', (e) => {
        e.preventDefault();
        if (draggedCard && draggedCard.element !== cardElement && draggedCard.sourceTrackId === trackId) {
            cardElement.classList.add('drag-over');
        }
    });
    cardElement.addEventListener('dragleave', () => cardElement.classList.remove('drag-over'));
    cardElement.addEventListener('drop', async (e) => {
        e.preventDefault();
        cardElement.classList.remove('drag-over');
        if (!draggedCard || draggedCard.element === cardElement || draggedCard.sourceTrackId !== trackId) return;
        const fromIdx = draggedCard.sourceIndex;
        const toIdx = cardIndex;
        const trackOrig = originalTracksData.find(t => t.id_track === trackId);
        if (trackOrig) {
            const temp = trackOrig.cards[fromIdx];
            trackOrig.cards[fromIdx] = trackOrig.cards[toIdx];
            trackOrig.cards[toIdx] = temp;
        }
        applyFiltersAndSort();
        showToast(`🔄 Карточки перемещены`);
    });
}

// Модальное окно добавления карточек
function openModalForTrack(track) {
    currentTrackForAdding = track;
    availableCards.forEach(card => card.selected = false);
    renderModalCardsList();
    document.getElementById('addCardsModal').style.display = 'block';
}

function renderModalCardsList() {
    const container = document.getElementById('modalCardsList');
    container.innerHTML = '';
    availableCards.forEach(card => {
        const item = document.createElement('div');
        item.className = 'modal-card-item';
        item.innerHTML = `
            <input type="checkbox" class="modal-card-checkbox" data-fakeid="${card.fakeId}" ${card.selected ? 'checked' : ''}>
            <div class="modal-card-info">
                <div class="modal-card-title">${escapeHtml(card.name)}</div>
                <div class="modal-card-details">
                    🏁 ${getPriorityDisplayText(card.importance_estimate)} | 👤 ${card.owner} | 📅 ${formatDate(card.deadline)}
                </div>
            </div>
        `;
        const checkbox = item.querySelector('.modal-card-checkbox');
        checkbox.addEventListener('change', (e) => {
            card.selected = e.target.checked;
            updateSelectAllCheckbox();
        });
        container.appendChild(item);
    });
    document.getElementById('selectAllCheckbox').checked = availableCards.every(c => c.selected);
}

function updateSelectAllCheckbox() {
    const selectAll = document.getElementById('selectAllCheckbox');
    if (selectAll) selectAll.checked = availableCards.every(c => c.selected);
}

function addSelectedCardsToTrack() {
    if (!currentTrackForAdding) return;
    const selected = availableCards.filter((c) => c.selected);

    const currentCount = currentTrackForAdding.cards.length;
    const availableSlots = 100 - currentCount;

    if (selected.length === 0) {
        showToast("⚠️ Ничего не выбрано!", true);
        return;
    }
    if (selected.length > availableSlots) {
        showToast(`❌ Нельзя добавить больше ${availableSlots} карточек! Лимит дорожки — 100`, true);
        return;
    }

    const origTrack = originalTracksData.find(t => t.id_track === currentTrackForAdding.id_track);
    if (origTrack) {
        const cardsToAdd = selected.map((card) => ({ ...card, id_card: null }));
        origTrack.cards.push(...cardsToAdd);
    }

    availableCards = availableCards.filter(c => !selected.some(s => s.fakeId === c.fakeId));

    if (availableCards.length < 100) {
        availableCards.push(...generateMockCards(100 - availableCards.length));
    }

    applyFiltersAndSort();
    closeModal();
    showToast(`✅ Добавлено ${selected.length} карточек! (${currentTrackForAdding.cards.length}/100)`);
}

function closeModal() {
    document.getElementById('addCardsModal').style.display = 'none';
    currentTrackForAdding = null;
}

// Загрузка доски с сервера
async function loadBoard() {
    try {
        const response = await fetch(`/api/board/${BOARD_ID}`);
        if (!response.ok) throw new Error('Ошибка загрузки');
        const data = await response.json();
        originalTracksData = data;
        tracksData = JSON.parse(JSON.stringify(originalTracksData));
        availableCards = generateMockCards(100);
        updateStats();
        renderBoard();
        showToast('✅ Данные загружены из БД');
    } catch (err) {
        showToast('❌ Ошибка подключения к серверу', true);
        document.getElementById('board').innerHTML = '<div class="loading">⚠️ Не удалось загрузить данные</div>';
    }
}

// Горячие клавиши для удаления карточек на доске (ТОЛЬКО когда сайдбар закрыт)
document.addEventListener('keydown', (e) => {
    if (e.key === 'Delete' && selectedCardIds.size > 0) {
        const sidebar = document.getElementById('sidebar');
        // Удаляем карточки только если сайдбар закрыт
        if (!sidebar.classList.contains('open')) {
            e.preventDefault();
            deleteSelectedCards();
        }
    }
});

// Сайдбар
function openCardSidebar(cardId, cardData) {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('overlay').classList.add('show');
    currentCardId = cardId;
    currentCardData = cardData;
    mode = 'view';
    activeTraces = new Set();
    deletedTables.clear();
    loadCardDetails(cardId, cardData);
}

function closeCardSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('overlay').classList.remove('show');
    currentCardId = null;
    currentCardData = null;
    mode = 'view';
    activeTraces = new Set();
    deletedTables.clear();
    if (selectedImage) {
        selectedImage.classList.remove('selected-image');
        selectedImage = null;
    }
}

function editMod(newMode) {
    if (newMode === 'view' && selectedImage) {
        selectedImage.classList.remove('selected-image');
        selectedImage = null;
    }
    mode = newMode;
    if (currentCardId) {
        loadCardDetails(currentCardId, currentCardData);
    }
}

// Удаление таблицы требований
window.deleteTable = function(tableType) {
    if (!confirm('Удалить таблицу требований?')) return;

    deletedTables.add(tableType);

    const section = document.getElementById(tableType + 'Section');
    const wrapper = document.getElementById(tableType + 'Wrapper');
    const addRowBtn = section.querySelector('button.primary');
    const deleteBtn = section.querySelector('.delete-table-btn');

    if (wrapper) wrapper.remove();
    if (addRowBtn) addRowBtn.remove();
    if (deleteBtn) deleteBtn.remove();

    section.classList.add('empty-table');

    const existingAddBtn = section.querySelector('.add-table-btn');
    if (!existingAddBtn) {
        const addBtn = document.createElement('button');
        addBtn.className = 'add-table-btn';
        addBtn.textContent = '+ Добавить таблицу';
        addBtn.onclick = () => addTable(tableType);
        section.appendChild(addBtn);
    }
};

// Добавление таблицы требований
window.addTable = function(tableType) {
    deletedTables.delete(tableType);

    const section = document.getElementById(tableType + 'Section');
    const existingAddBtn = section.querySelector('.add-table-btn');
    if (existingAddBtn) existingAddBtn.remove();

    section.classList.remove('empty-table');

    const header = section.querySelector('.section-header');
    let deleteBtn = header.querySelector('.delete-table-btn');
    if (!deleteBtn) {
        deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-table-btn';
        deleteBtn.textContent = '🗑️';
        deleteBtn.title = 'Удалить таблицу';
        deleteBtn.onclick = () => deleteTable(tableType);
        header.appendChild(deleteBtn);
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'table-wrapper';
    wrapper.id = tableType + 'Wrapper';

    let tableHtml = '';
    if (tableType === 'userReqs') {
        tableHtml = `
            <table>
                <thead>
                    <tr><th></th><th>Роль</th><th>Действие</th><th>Ценность</th><th>Сценарий использования</th><th>Критерий</th><th>Приоритет</th><th></th></tr>
                </thead>
                <tbody id="userReqsBody"></tbody>
            </table>
        `;
    } else if (tableType === 'funcReqs') {
        tableHtml = `
            <table>
                <thead>
                    <tr><th></th><th>Описание</th><th>Детализация</th><th>Приоритет</th><th></th></tr>
                </thead>
                <tbody id="funcReqsBody"></tbody>
            </table>
        `;
    } else if (tableType === 'nonFuncReqs') {
        tableHtml = `
            <table>
                <thead>
                    <tr><th></th><th>Описание</th><th>Пояснение</th><th></th></tr>
                </thead>
                <tbody id="nonFuncReqsBody"></tbody>
            </table>
        `;
    } else if (tableType === 'integration') {
        tableHtml = `
            <table>
                <tr><th>API</th><td><input class="input-table-field" data-field="api_endpoint" placeholder="Введите API"></td></tr>
                <tr><th>Тип данных</th><td><input class="input-table-field" data-field="data_format" placeholder="Например: JSON"></td></tr>
                <tr><th>Скрипт</th><td><div class="editable-cell" contenteditable="true" data-field="scripts"></div></td></tr>
            </table>
        `;
    }

    wrapper.innerHTML = tableHtml;
    section.insertBefore(wrapper, section.querySelector('button.primary') || section.querySelector('.add-table-btn') || null);

    let addRowBtn = section.querySelector('button.primary');
    if (!addRowBtn && tableType !== 'integration') {
        addRowBtn = document.createElement('button');
        addRowBtn.className = 'primary';
        addRowBtn.textContent = '+ Добавить требование';
        addRowBtn.onclick = tableType === 'userReqs' ? addUserRow :
                          tableType === 'funcReqs' ? addFunctionalRow : addNonFunctionalRow;
        section.appendChild(addRowBtn);
    }
};

// Вставка картинок через Ctrl+V
function handlePaste(e) {
    if (mode !== 'edit') return;
    const target = e.target;
    if (!target.classList.contains('editable-cell')) return;

    const items = e.clipboardData?.items;
    if (!items) return;
    for (let item of items) {
        if (item.type.indexOf('image') !== -1) {
            e.preventDefault();
            const blob = item.getAsFile();
            const reader = new FileReader();
            reader.onload = (event) => {
                const img = document.createElement('img');
                img.src = event.target.result;
                img.style.maxWidth = '100%';
                img.style.maxHeight = '200px';
                img.style.display = 'block';
                img.style.margin = '5px 0';

                const selection = window.getSelection();
                if (selection.rangeCount) {
                    const range = selection.getRangeAt(0);
                    range.deleteContents();
                    range.insertNode(img);
                    range.collapse(false);
                }
            };
            reader.readAsDataURL(blob);
            break;
        }
    }
}

document.addEventListener('paste', handlePaste);

// Обработчик клика по изображению для его выделения
document.addEventListener('click', (e) => {
    if (mode !== 'edit') return;

    const img = e.target.closest('img');
    if (!img || !img.closest('.editable-cell')) return;

    if (selectedImage) {
        selectedImage.classList.remove('selected-image');
    }

    img.classList.add('selected-image');
    selectedImage = img;

    e.stopPropagation();
});

// Снятие выделения при клике вне изображения
document.addEventListener('click', (e) => {
    if (!e.target.closest('img') && selectedImage) {
        selectedImage.classList.remove('selected-image');
        selectedImage = null;
    }
});

// Удаление картинок через Delete (ТОЛЬКО в режиме редактирования сайдбара)
document.addEventListener('keydown', (e) => {
    // Игнорируем если не режим редактирования
    if (mode !== 'edit') return;

    // Игнорируем если не Delete
    if (e.key !== 'Delete') {
        // Обработка Escape
        if (e.key === 'Escape' && selectedImage) {
            selectedImage.classList.remove('selected-image');
            selectedImage = null;
        }
        return;
    }

    // Проверяем, что сайдбар открыт
    const sidebar = document.getElementById('sidebar');
    if (!sidebar.classList.contains('open')) return;

    // Если есть выделенное изображение
    if (selectedImage) {
        e.preventDefault();
        e.stopPropagation();
        selectedImage.remove();
        selectedImage = null;
        return;
    }

    // Проверяем выделение через Selection API
    const selection = window.getSelection();
    if (selection.rangeCount) {
        const range = selection.getRangeAt(0);
        const container = range.commonAncestorContainer;

        let img = null;
        if (container.nodeType === 1) {
            img = container.closest('img');
        } else if (container.parentElement) {
            img = container.parentElement.closest('img');
        }

        // Проверяем, что изображение внутри редактируемой ячейки
        if (img && img.tagName === 'IMG' && img.closest('.editable-cell')) {
            e.preventDefault();
            e.stopPropagation();
            img.remove();
        }
    }
});

// Рендер матрицы трассировки
function renderTraceabilityMatrix(userReqs, funcReqs) {
    if (!userReqs.length || !funcReqs.length) {
        return `<p></p>`;
    }

    const userCodes = userReqs.map(r => r.encoding || '—').filter(c => c !== '—');
    const funcCodes = funcReqs.map(r => r.encoding || '—').filter(c => c !== '—');

    if (!userCodes.length || !funcCodes.length) {
        return `<p style="margin-left: 12px; color: #000;">Нет кодов требований для построения матрицы</p>`;
    }

    let html = `
        <div class="table-wrapper" id="traceWrapper">
            <table>
                <thead>
                    <tr>
                        <th></th>
                        ${funcCodes.map(code => `<th>${escapeHtml(code)}</th>`).join('')}
                    </tr>
                </thead>
                <tbody id="traceBody">
    `;

    userCodes.forEach(userCode => {
        html += `<tr>`;
        html += `<th>${escapeHtml(userCode)}</th>`;
        funcCodes.forEach(funcCode => {
            const key = `${userCode}|${funcCode}`;
            const hasPlus = activeTraces.has(key);
            html += `<td style="text-align: center;">
                <button class="trace-link-btn" onclick="toggleTrace(this, '${userCode}', '${funcCode}')" ${mode !== 'edit' ? 'disabled' : ''}>${hasPlus ? '+' : ''}</button>
            </td>`;
        });
        html += `</tr>`;
    });

    html += `
                </tbody>
            </table>
        </div>
    `;

    return html;
}

window.toggleTrace = function(btn, userCode, funcCode) {
    if (mode !== 'edit') return;

    const key = `${userCode}|${funcCode}`;
    if (activeTraces.has(key)) {
        activeTraces.delete(key);
        btn.textContent = '';
    } else {
        activeTraces.add(key);
        btn.textContent = '+';
    }
};

// Загрузка данных карточки в сайдбар
async function loadCardDetails(cardId, cardData) {
    const titleEl = document.getElementById('sidebar-title');
    const contentEl = document.getElementById('sidebar-content');

    let trackName = '—';
    let trackIndex = 1;
    for (const track of originalTracksData) {
        const found = track.cards.find(c => (c.id_card || c.fakeId) == cardId);
        if (found) {
            trackName = track.name;
            trackIndex = (originalTracksData.findIndex(t => t.id_track === track.id_track) % 5) + 1;
            break;
        }
    }

    titleEl.innerHTML = `
        <span>${cardData?.name || `Карточка #${cardId}`}</span>
        <span class="status-badge status-${trackIndex}">${trackName}</span>
    `;
    contentEl.innerHTML = `<div class="loading">Загрузка...</div>`;

    try {
        const response = await fetch(`/api/requirements/?card=${cardId}`);
        if (!response.ok) throw new Error('Ошибка загрузки данных карточки');
        const data = await response.json();

        const card = data.card_requirements?.[0] || {};
        const userReqs = data.user_requirements || [];
        const funcReqs = data.functional_requirements || [];
        const nonFuncReqs = data.non_functional_requirements || [];
        const integration = data.integrations_and_data?.[0] || {};

        const userReqsEmpty = userReqs.length === 0;
        const funcReqsEmpty = funcReqs.length === 0;
        const nonFuncReqsEmpty = nonFuncReqs.length === 0;
        const integrationEmpty = !integration || (!integration.api_endpoint && !integration.data_format && !integration.scripts);

        let html = `
            <div class="doc">
                <table class="doc-table">
                    <tr><th>№</th><th>Наименование</th><th>Значение</th></tr>
                    <tr><td>1</td><td>Краткое описание</td><td>${mode === 'edit' ? `<input class="input-table-field" data-field="short_description" value="${escapeHtml(card.short_description || '')}">` : escapeHtml(card.short_description || '-')}</td></tr>
                    <tr><td>2</td><td>Владелец</td><td>${mode === 'edit' ? `<input class="input-table-field" data-field="owner" value="${escapeHtml(card.owner || '')}">` : escapeHtml(card.owner || '-')}</td></tr>
                    <tr><td>3</td><td>Заказчик</td><td>${mode === 'edit' ? `<input class="input-table-field" data-field="customer" value="${escapeHtml(card.customer || '')}">` : escapeHtml(card.customer || '-')}</td></tr>
                    <tr><td>4</td><td>Название проекта</td><td>${mode === 'edit' ? `<input class="input-table-field" data-field="name" value="${escapeHtml(card.name || '')}">` : escapeHtml(card.name || '-')}</td></tr>
                    <tr><td>5</td><td>Дедлайн</td><td>${mode === 'edit' ? `<input type="date" class="input-table-field" data-field="deadline" value="${card.deadline ? card.deadline.split('T')[0] : ''}">` : formatDate(card.deadline)}</td></tr>
                </table>

                <!-- Пользовательские требования -->
                <div class="doc-section pink" id="userReqsSection">
                    <div class="section-header">
                        <h3>6. Пользовательские требования</h3>
                        ${mode === 'edit' && !userReqsEmpty ? `<button class="delete-table-btn" onclick="deleteTable('userReqs')" title="Удалить таблицу">🗑️</button>` : ''}
                    </div>
                    ${!userReqsEmpty ? `
                        <div class="table-wrapper" id="userReqsWrapper">
                            <table>
                                <thead>
                                    <tr><th></th><th>Роль</th><th>Действие</th><th>Ценность</th><th>Сценарий использования</th><th>Критерий</th><th>Приоритет</th>${mode === 'edit' ? '<th></th>' : ''}</tr>
                                </thead>
                                <tbody id="userReqsBody">
                                    ${renderUserReqsRows(userReqs)}
                                </tbody>
                            </table>
                        </div>
                    ` : ''}
                    ${mode === 'edit' && userReqsEmpty ? `<button class="add-table-btn" onclick="addTable('userReqs')">+ Добавить таблицу</button>` : ''}
                    ${mode === 'edit' && !userReqsEmpty ? `<button onclick="addUserRow()" class="primary" style="margin-left: 12px; margin-top: 10px;">+ Добавить требование</button>` : ''}
                </div>

                <!-- Функциональные требования -->
                <div class="doc-section purple" id="funcReqsSection">
                    <div class="section-header">
                        <h3>7. Функциональные требования</h3>
                        ${mode === 'edit' && !funcReqsEmpty ? `<button class="delete-table-btn" onclick="deleteTable('funcReqs')" title="Удалить таблицу">🗑️</button>` : ''}
                    </div>
                    ${!funcReqsEmpty ? `
                        <div class="table-wrapper" id="funcReqsWrapper">
                            <table>
                                <thead>
                                    <tr><th></th><th>Описание</th><th>Детализация</th><th>Приоритет</th>${mode === 'edit' ? '<th></th>' : ''}</tr>
                                </thead>
                                <tbody id="funcReqsBody">
                                    ${renderFuncReqsRows(funcReqs)}
                                </tbody>
                            </table>
                        </div>
                    ` : ''}
                    ${mode === 'edit' && funcReqsEmpty ? `<button class="add-table-btn" onclick="addTable('funcReqs')">+ Добавить таблицу</button>` : ''}
                    ${mode === 'edit' && !funcReqsEmpty ? `<button onclick="addFunctionalRow()" class="primary" style="margin-left: 12px; margin-top: 10px;">+ Добавить требование</button>` : ''}
                </div>

                <!-- Нефункциональные требования -->
                <div class="doc-section blue" id="nonFuncReqsSection">
                    <div class="section-header">
                        <h3>8. Нефункциональные требования</h3>
                        ${mode === 'edit' && !nonFuncReqsEmpty ? `<button class="delete-table-btn" onclick="deleteTable('nonFuncReqs')" title="Удалить таблицу">🗑️</button>` : ''}
                    </div>
                    ${!nonFuncReqsEmpty ? `
                        <div class="table-wrapper" id="nonFuncReqsWrapper">
                            <table>
                                <thead>
                                    <tr><th></th><th>Описание</th><th>Пояснение</th>${mode === 'edit' ? '<th></th>' : ''}</tr>
                                </thead>
                                <tbody id="nonFuncReqsBody">
                                    ${renderNonFuncReqsRows(nonFuncReqs)}
                                </tbody>
                            </table>
                        </div>
                    ` : ''}
                    ${mode === 'edit' && nonFuncReqsEmpty ? `<button class="add-table-btn" onclick="addTable('nonFuncReqs')">+ Добавить таблицу</button>` : ''}
                    ${mode === 'edit' && !nonFuncReqsEmpty ? `<button onclick="addNonFunctionalRow()" class="primary" style="margin-left: 12px; margin-top: 10px;">+ Добавить требование</button>` : ''}
                </div>

                <!-- Интеграции и данные -->
                <div class="doc-section green" id="integrationSection">
                    <div class="section-header">
                        <h3 style="margin-left: 12px;">9. Интеграции и данные</h3>
                        ${mode === 'edit' && !integrationEmpty ? `<button class="delete-table-btn" onclick="deleteTable('integration')" title="Удалить таблицу">🗑️</button>` : ''}
                    </div>
                    ${!integrationEmpty ? `
                        <div class="table-wrapper" id="integrationWrapper">
                            <table>
                                <tr><th>API</th><td>${mode === 'edit' ? `<input class="input-table-field" data-field="api_endpoint" value="${escapeHtml(integration.api_endpoint || '')}">` : escapeHtml(integration.api_endpoint || 'нет данных')}</td></tr>
                                <tr><th>Тип данных</th><td>${mode === 'edit' ? `<input class="input-table-field" data-field="data_format" value="${escapeHtml(integration.data_format || '')}">` : escapeHtml(integration.data_format || 'нет данных')}</td></tr>
                                <tr><th>Скрипт</th><td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="scripts">${integration.scripts || ''}</div>` : (integration.scripts || 'нет данных')}</td></tr>
                            </table>
                        </div>
                    ` : ''}
                    ${mode === 'edit' && integrationEmpty ? `<button class="add-table-btn" onclick="addTable('integration')">+ Добавить таблицу</button>` : ''}
                </div>

                <!-- Трассировка (матрица) -->
                <div class="doc-section trace-section" id="traceSection">
                    <div class="section-header">
                        <h3>10. Трассировка (матрица)</h3>
                    </div>
                    ${renderTraceabilityMatrix(userReqs, funcReqs)}
                </div>

                <div class="button_wrapper">
                    ${mode === 'view' ?
                        `<button onclick="closeCardSidebar()" class="danger">❌ Закрыть</button>` :
                        `<button onclick="saveCardRequirements(${cardId})" class="success">💾 Сохранить</button>
                         <button onclick="editMod('view')" class="danger">❌ Отмена</button>`
                    }
                </div>
            </div>
        `;

        contentEl.innerHTML = html;

        contentEl.addEventListener('dblclick', (e) => {
            if (mode === 'view') {
                editMod('edit');
            }
        });

    } catch (err) {
        console.error('Ошибка загрузки карточки:', err);
        contentEl.innerHTML = `<p class="error">Ошибка загрузки: ${err.message}</p>
                              <div class="button_wrapper"><button class="danger" onclick="closeCardSidebar()">Закрыть</button></div>`;
    }
}

// Рендер строк таблиц требований
function renderUserReqsRows(reqs) {
    if (!reqs.length) return '';
    return reqs.map(r => `
        <tr data-id="${r.id_pt || ''}">
            <td>${mode === 'edit' ? `<input class="input-table-field" data-field="encoding" value="${escapeHtml(r.encoding || '')}">` : escapeHtml(r.encoding || '-')}</td>
            <td>${mode === 'edit' ? `<input class="input-table-field" data-field="role" value="${escapeHtml(r.role || '')}">` : escapeHtml(r.role || '-')}</td>
            <td>${mode === 'edit' ? `<input class="input-table-field" data-field="action" value="${escapeHtml(r.action || '')}">` : escapeHtml(r.action || '-')}</td>
            <td>${mode === 'edit' ? `<input class="input-table-field" data-field="value" value="${escapeHtml(r.value || '')}">` : escapeHtml(r.value || '-')}</td>
            <td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="usage_scenario">${r.usage_scenario || ''}</div>` : (r.usage_scenario || '-')}</td>
            <td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="acceptance_criteria">${r.acceptance_criteria || ''}</div>` : (r.acceptance_criteria || '-')}</td>
            <td>${mode === 'edit' ?
                `<select class="input-table-field" data-field="priority">
                    <option value="Низкий" ${r.priority === 'Низкий' ? 'selected' : ''}>Низкий</option>
                    <option value="Средний" ${r.priority === 'Средний' ? 'selected' : ''}>Средний</option>
                    <option value="Высокий" ${r.priority === 'Высокий' ? 'selected' : ''}>Высокий</option>
                </select>` : escapeHtml(r.priority || '-')}</td>
            ${mode === 'edit' ? `<td><button class="delete-row-btn" onclick="deleteRow(this)">×</button></td>` : ''}
        </tr>
    `).join('');
}

function renderFuncReqsRows(reqs) {
    if (!reqs.length) return '';
    return reqs.map(r => `
        <tr data-id="${r.id_ft || ''}">
            <td>${mode === 'edit' ? `<input class="input-table-field" data-field="encoding" value="${escapeHtml(r.encoding || '')}">` : escapeHtml(r.encoding || '-')}</td>
            <td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="short_description">${r.short_description || ''}</div>` : (r.short_description || '-')}</td>
            <td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="details">${r.details || ''}</div>` : (r.details || '-')}</td>
            <td>${mode === 'edit' ?
                `<select class="input-table-field" data-field="priority">
                    <option value="Низкий" ${r.priority === 'Низкий' ? 'selected' : ''}>Низкий</option>
                    <option value="Средний" ${r.priority === 'Средний' ? 'selected' : ''}>Средний</option>
                    <option value="Высокий" ${r.priority === 'Высокий' ? 'selected' : ''}>Высокий</option>
                </select>` : escapeHtml(r.priority || '-')}</td>
            ${mode === 'edit' ? `<td><button class="delete-row-btn" onclick="deleteRow(this)">×</button></td>` : ''}
        </tr>
    `).join('');
}

function renderNonFuncReqsRows(reqs) {
    if (!reqs.length) return '';
    return reqs.map(r => `
        <tr data-id="${r.id_nft || ''}">
            <td>${mode === 'edit' ? `<input class="input-table-field" data-field="encoding" value="${escapeHtml(r.encoding || '')}">` : escapeHtml(r.encoding || '-')}</td>
            <td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="description">${r.description || ''}</div>` : (r.description || '-')}</td>
            <td>${mode === 'edit' ? `<div class="editable-cell" contenteditable="true" data-field="explanation">${r.explanation || ''}</div>` : (r.explanation || '-')}</td>
            ${mode === 'edit' ? `<td><button class="delete-row-btn" onclick="deleteRow(this)">×</button></td>` : ''}
        </tr>
    `).join('');
}

// Удаление строки
window.deleteRow = function(btn) {
    const row = btn.closest('tr');
    const id = row.dataset.id;
    if (id) {
        row.style.opacity = '0.5';
        row.style.textDecoration = 'line-through';
        row.dataset.toDelete = 'true';
    } else {
        row.remove();
    }
};

// Добавление строк
let newRowCounter = 0;

window.addUserRow = function() {
    const tbody = document.getElementById('userReqsBody');
    if (!tbody) return;
    const row = document.createElement('tr');
    row.dataset.id = `new-${++newRowCounter}`;
    row.innerHTML = `
        <td><input class="input-table-field" data-field="encoding"></td>
        <td><input class="input-table-field" data-field="role"></td>
        <td><input class="input-table-field" data-field="action"></td>
        <td><input class="input-table-field" data-field="value"></td>
        <td><div class="editable-cell" contenteditable="true" data-field="usage_scenario"></div></td>
        <td><div class="editable-cell" contenteditable="true" data-field="acceptance_criteria"></div></td>
        <td>
            <select class="input-table-field" data-field="priority">
                <option value="Низкий">Низкий</option>
                <option value="Средний" selected>Средний</option>
                <option value="Высокий">Высокий</option>
            </select>
        </td>
        <td><button class="delete-row-btn" onclick="deleteRow(this)">×</button></td>
    `;
    tbody.appendChild(row);
};

window.addFunctionalRow = function() {
    const tbody = document.getElementById('funcReqsBody');
    if (!tbody) return;
    const row = document.createElement('tr');
    row.dataset.id = `new-${++newRowCounter}`;
    row.innerHTML = `
        <td><input class="input-table-field" data-field="encoding"></td>
        <td><div class="editable-cell" contenteditable="true" data-field="short_description"></div></td>
        <td><div class="editable-cell" contenteditable="true" data-field="details"></div></td>
        <td>
            <select class="input-table-field" data-field="priority">
                <option value="Низкий">Низкий</option>
                <option value="Средний" selected>Средний</option>
                <option value="Высокий">Высокий</option>
            </select>
        </td>
        <td><button class="delete-row-btn" onclick="deleteRow(this)">×</button></td>
    `;
    tbody.appendChild(row);
};

window.addNonFunctionalRow = function() {
    const tbody = document.getElementById('nonFuncReqsBody');
    if (!tbody) return;
    const row = document.createElement('tr');
    row.dataset.id = `new-${++newRowCounter}`;
    row.innerHTML = `
        <td><input class="input-table-field" data-field="encoding"></td>
        <td><div class="editable-cell" contenteditable="true" data-field="description"></div></td>
        <td><div class="editable-cell" contenteditable="true" data-field="explanation"></div></td>
        <td><button class="delete-row-btn" onclick="deleteRow(this)">×</button></td>
    `;
    tbody.appendChild(row);
};

// Сохранение требований
async function saveCardRequirements(cardId) {
    const data = {
        card_requirements: { update: [] },
        user_requirements: { update: [], create: [], delete: [] },
        functional_requirements: { update: [], create: [], delete: [] },
        non_functional_requirements: { update: [], create: [], delete: [] },
        integrations_and_data: { update: [] }
    };

    // Получаем текущие данные с сервера, чтобы знать какие ID удалять
    let currentData = null;
    try {
        const response = await fetch(`/api/requirements/?card=${cardId}`);
        if (response.ok) {
            currentData = await response.json();
        }
    } catch (err) {
        console.error('Ошибка получения текущих данных:', err);
    }

    // Если таблица пользовательских требований удалена - помечаем все записи на удаление
    if (deletedTables.has('userReqs')) {
        if (currentData && currentData.user_requirements) {
            currentData.user_requirements.forEach(req => {
                if (req.id_pt) {
                    data.user_requirements.delete.push(req.id_pt);
                }
            });
        }
    } else {
        collectTableData('user_requirements', '#userReqsBody tr', ['encoding', 'role', 'action', 'value', 'usage_scenario', 'acceptance_criteria', 'priority']);
    }

    // Если таблица функциональных требований удалена
    if (deletedTables.has('funcReqs')) {
        if (currentData && currentData.functional_requirements) {
            currentData.functional_requirements.forEach(req => {
                if (req.id_ft) {
                    data.functional_requirements.delete.push(req.id_ft);
                }
            });
        }
    } else {
        collectTableData('functional_requirements', '#funcReqsBody tr', ['encoding', 'short_description', 'details', 'priority']);
    }

    // Если таблица нефункциональных требований удалена
    if (deletedTables.has('nonFuncReqs')) {
        if (currentData && currentData.non_functional_requirements) {
            currentData.non_functional_requirements.forEach(req => {
                if (req.id_nft) {
                    data.non_functional_requirements.delete.push(req.id_nft);
                }
            });
        }
    } else {
        collectTableData('non_functional_requirements', '#nonFuncReqsBody tr', ['encoding', 'description', 'explanation']);
    }

    const mainInputs = document.querySelectorAll('.doc-table .input-table-field');
    const mainObj = {};
    mainInputs.forEach(input => mainObj[input.dataset.field] = input.value.trim());
    mainObj.id_card = cardId;
    data.card_requirements.update.push(mainObj);

    // Если таблица интеграций удалена - отправляем пустой объект
    if (deletedTables.has('integration')) {
        data.integrations_and_data.update.push({
            id_card: cardId,
            api_endpoint: '',
            data_format: '',
            scripts: ''
        });
    } else {
        const integrationInputs = document.querySelectorAll('.doc-section.green .input-table-field');
        const intObj = {};
        integrationInputs.forEach(input => intObj[input.dataset.field] = input.value.trim());
        intObj.id_card = cardId;
        data.integrations_and_data.update.push(intObj);

        const scriptsDiv = document.querySelector('.doc-section.green [data-field="scripts"]');
        if (scriptsDiv) {
            intObj.scripts = scriptsDiv.innerHTML.trim();
        }
    }

    function collectTableData(type, selector, fields) {
        const rows = document.querySelectorAll(selector);
        rows.forEach(row => {
            const id = row.dataset.id;
            if (row.dataset.toDelete === 'true') {
                if (id && !id.startsWith('new')) data[type].delete.push(Number(id));
                return;
            }
            const obj = {};
            fields.forEach(field => {
                const input = row.querySelector(`[data-field="${field}"]`);
                if (input) {
                    if (input.tagName === 'DIV' && input.contentEditable === 'true') {
                        obj[field] = input.innerHTML.trim();
                    } else {
                        obj[field] = input.value.trim();
                    }
                }
            });
            if (id && id.startsWith('new')) {
                obj.id_card = cardId;
                data[type].create.push(obj);
            } else if (id) {
                obj[type === 'user_requirements' ? 'id_pt' : type === 'functional_requirements' ? 'id_ft' : 'id_nft'] = Number(id);
                obj.id_card = cardId;
                data[type].update.push(obj);
            }
        });
    }

    // Удаляем дубликаты в delete массивах
    data.user_requirements.delete = [...new Set(data.user_requirements.delete)];
    data.functional_requirements.delete = [...new Set(data.functional_requirements.delete)];
    data.non_functional_requirements.delete = [...new Set(data.non_functional_requirements.delete)];

    console.log('Отправляемые данные:', data);

    try {
        const res = await fetch('/api/requirements/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!res.ok) throw new Error('Ошибка сохранения');

        showToast('✅ Сохранено!');
        deletedTables.clear();
        editMod('view');
    } catch (err) {
        showToast('❌ Ошибка: ' + err.message, true);
    }
}

window.saveCardRequirements = saveCardRequirements;

// Инициализация модального окна
function initModal() {
    const modal = document.getElementById('addCardsModal');
    document.getElementById('closeModalBtn').onclick = closeModal;
    document.getElementById('modalCancelBtn').onclick = closeModal;
    document.getElementById('modalAddBtn').onclick = addSelectedCardsToTrack;
    document.getElementById('selectAllCheckbox').onchange = (e) => {
        availableCards.forEach(c => c.selected = e.target.checked);
        renderModalCardsList();
    };
    window.onclick = (e) => { if (e.target === modal) closeModal(); };
    document.getElementById('overlay').onclick = closeCardSidebar;
}

// Запуск
initFilters();
initModal();
loadBoard();
const express = require('express');
const { Pool } = require('pg');
const path = require('path');

const app = express();

// Увеличенный лимит для передачи base64-картинок
app.use(express.json({ limit: '50mb' }));

// Подключение к базе данных дорожек
const poolTracks = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'db_kanban_tracks',
    password: '123456',
    port: 5432,
});

// Подключение к базе данных карточек и требований
const poolCards = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'db_сards_requirements',
    password: '123456',
    port: 5432,
});

// Раздача статических файлов (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, '../public')));

// Главная страница
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Получение всех требований для конкретной карточки
app.get('/api/requirements/', async (req, res) => {
    const cardId = req.query.card;

    try {
        const tableNames = [
            'user_requirements',
            'functional_requirements',
            'non_functional_requirements',
            'integrations_and_data',
            'card_requirements',
        ];

        const results = {};

        for (const tableName of tableNames) {
            const query = `SELECT * FROM ${tableName} WHERE id_card = $1`;
            const result = await poolCards.query(query, [cardId]);
            results[tableName] = result.rows;
        }

        res.json(results);
    } catch (error) {
        console.error('Ошибка получения требований:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Получение структуры доски (дорожки и карточки)
app.get('/api/board/:boardId', async (req, res) => {
    const boardId = req.params.boardId;

    try {
        // Дорожки
        const tracksResult = await poolTracks.query(
            'SELECT * FROM tracks_kanban_board WHERE id_board = $1 ORDER BY position_track',
            [boardId]
        );
        const tracks = tracksResult.rows;

        // Карточки
        const cardsResult = await poolCards.query(
            'SELECT id_card, name, FIO_owner, deadline, importance_estimate::text as importance_estimate, id_track FROM card_requirements ORDER BY id_card'
        );
        const cards = cardsResult.rows;

        // Собираем доску
        const boardData = tracks.map(track => ({
            ...track,
            cards: cards.filter(card => card.id_track === track.id_track)
        }));

        res.json(boardData);
    } catch (err) {
        console.error('Ошибка получения доски:', err);
        res.status(500).json({ error: 'Ошибка сервера: ' + err.message });
    }
});

// Переименование дорожки
app.put('/api/tracks/:trackId', async (req, res) => {
    const trackId = parseInt(req.params.trackId);
    const { name } = req.body;

    if (!name || name.trim() === '') {
        return res.status(400).json({ error: 'Название не может быть пустым' });
    }

    try {
        const result = await poolTracks.query(
            'UPDATE tracks_kanban_board SET name = $1, updated_at = CURRENT_TIMESTAMP WHERE id_track = $2 RETURNING *',
            [name.trim(), trackId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Дорожка не найдена' });
        }

        res.json({ success: true, track: result.rows[0] });
    } catch (err) {
        console.error('Ошибка обновления дорожки:', err);
        res.status(500).json({ error: 'Ошибка обновления: ' + err.message });
    }
});

// Удаление карточки и всех связанных данных
app.delete('/api/cards/:cardId', async (req, res) => {
    const cardId = parseInt(req.params.cardId);

    try {
        // Удаляем связанные требования
        await poolCards.query('DELETE FROM user_requirements WHERE id_card = $1', [cardId]);
        await poolCards.query('DELETE FROM functional_requirements WHERE id_card = $1', [cardId]);
        await poolCards.query('DELETE FROM non_functional_requirements WHERE id_card = $1', [cardId]);
        await poolCards.query('DELETE FROM integrations_and_data WHERE id_card = $1', [cardId]);

        // Удаляем саму карточку
        const result = await poolCards.query('DELETE FROM card_requirements WHERE id_card = $1 RETURNING *', [cardId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Карточка не найдена' });
        }

        res.json({ success: true, deletedCard: result.rows[0] });
    } catch (err) {
        console.error('Ошибка удаления карточки:', err);
        res.status(500).json({ error: 'Ошибка удаления: ' + err.message });
    }
});

// Перемещение карточки на другую дорожку
app.put('/api/cards/:cardId/move', async (req, res) => {
    const cardId = parseInt(req.params.cardId);
    const { targetTrackId } = req.body;

    try {
        const result = await poolCards.query(
            'UPDATE card_requirements SET id_track = $1 WHERE id_card = $2 RETURNING *',
            [targetTrackId, cardId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Карточка не найдена' });
        }

        res.json({ success: true, card: result.rows[0] });
    } catch (err) {
        console.error('Ошибка перемещения карточки:', err);
        res.status(500).json({ error: 'Ошибка перемещения: ' + err.message });
    }
});

// Сохранение всех изменений требований
app.post('/api/requirements/save', async (req, res) => {
    const data = req.body;
    const client = await poolCards.connect();

    try {
        await client.query('BEGIN');

        // Основные данные карточки
        if (data.card_requirements?.update?.length) {
            for (const item of data.card_requirements.update) {
                await client.query(
                    `UPDATE card_requirements
                     SET name = $1, short_description = $2, FIO_owner = $3,
                         customer = $4, deadline = $5
                     WHERE id_card = $6`,
                    [
                        item.name || '-',
                        item.short_description || '-',
                        item.FIO_owner || '-',
                        item.customer || '-',
                        item.deadline || null,
                        item.id_card
                    ]
                );
            }
        }

        // Функциональные требования
        if (data.functional_requirements) {
            const { update = [], create = [], delete: del = [] } = data.functional_requirements;

            for (const item of update) {
                await client.query(
                    `UPDATE functional_requirements
                     SET encoding = $1, short_description = $2, details = $3, priority = $4
                     WHERE id_ft = $5`,
                    [item.encoding, item.short_description, item.details, item.priority, item.id_ft]
                );
            }

            for (const item of create) {
                await client.query(
                    `INSERT INTO functional_requirements (id_card, encoding, short_description, details, priority)
                     VALUES ($1, $2, $3, $4, $5)`,
                    [item.id_card, item.encoding, item.short_description, item.details, item.priority]
                );
            }

            for (const id of del) {
                await client.query(`DELETE FROM functional_requirements WHERE id_ft = $1`, [id]);
            }
        }

        // Пользовательские требования
        if (data.user_requirements) {
            const { update = [], create = [], delete: del = [] } = data.user_requirements;

            for (const item of update) {
                await client.query(
                    `UPDATE user_requirements
                     SET encoding = $1, role = $2, action = $3, value = $4,
                         usage_scenario = $5, acceptance_criteria = $6, priority = $7
                     WHERE id_pt = $8`,
                    [item.encoding, item.role, item.action, item.value, item.usage_scenario, item.acceptance_criteria, item.priority, item.id_pt]
                );
            }

            for (const item of create) {
                await client.query(
                    `INSERT INTO user_requirements (id_card, encoding, role, action, value, usage_scenario, acceptance_criteria, priority)
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
                    [item.id_card, item.encoding, item.role, item.action, item.value, item.usage_scenario, item.acceptance_criteria, item.priority]
                );
            }

            for (const id of del) {
                await client.query(`DELETE FROM user_requirements WHERE id_pt = $1`, [id]);
            }
        }

        // Нефункциональные требования
        if (data.non_functional_requirements) {
            const { update = [], create = [], delete: del = [] } = data.non_functional_requirements;

            for (const item of update) {
                await client.query(
                    `UPDATE non_functional_requirements
                     SET encoding = $1, description = $2, explanation = $3
                     WHERE id_nft = $4`,
                    [item.encoding, item.description, item.explanation, item.id_nft]
                );
            }

            for (const item of create) {
                await client.query(
                    `INSERT INTO non_functional_requirements (id_card, encoding, description, explanation)
                     VALUES ($1, $2, $3, $4)`,
                    [item.id_card, item.encoding, item.description, item.explanation]
                );
            }

            for (const id of del) {
                await client.query(`DELETE FROM non_functional_requirements WHERE id_nft = $1`, [id]);
            }
        }

        // Интеграции и данные
        if (data.integrations_and_data?.update?.length) {
            for (const item of data.integrations_and_data.update) {
                const existing = await client.query(
                    `SELECT id_integration FROM integrations_and_data WHERE id_card = $1 LIMIT 1`,
                    [item.id_card]
                );

                if (existing.rows.length > 0) {
                    await client.query(
                        `UPDATE integrations_and_data
                         SET api_endpoint = $1, data_format = $2, scripts = $3
                         WHERE id_card = $4`,
                        [item.api_endpoint, item.data_format, item.scripts, item.id_card]
                    );
                } else {
                    await client.query(
                        `INSERT INTO integrations_and_data (id_card, api_endpoint, data_format, scripts)
                         VALUES ($1, $2, $3, $4)`,
                        [item.id_card, item.api_endpoint, item.data_format, item.scripts]
                    );
                }
            }
        }

        await client.query('COMMIT');
        res.json({ success: true });
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('Ошибка сохранения требований:', err);
        res.status(500).json({ error: err.message });
    } finally {
        client.release();
    }
});

// Проверка подключения к базам данных
async function testConnections() {
    try {
        await poolTracks.query('SELECT NOW()');
        console.log('✅ Успешное подключение к db_kanban_tracks');
    } catch (err) {
        console.error('❌ Ошибка подключения к db_kanban_tracks:', err.message);
    }

    try {
        await poolCards.query('SELECT NOW()');
        console.log('✅ Успешное подключение к db_cards_requirements');
    } catch (err) {
        console.error('❌ Ошибка подключения к db_cards_requirements:', err.message);
    }
}

// Запуск сервера
const PORT = 3000;
app.listen(PORT, async () => {
    console.log(`🚀 Сервер запущен на порту ${PORT}`);
    await testConnections();
});